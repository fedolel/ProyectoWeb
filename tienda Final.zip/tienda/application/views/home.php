

<div class="site-blocks-cover aos-init aos-animate" style="background-image: url(http://www.hoopjordan.net/wp-content/uploads/2018/11/Nike-Kyrie-5-15.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-start align-items-md-center justify-content-end">
          <div class="col-md-4 text-center text-md-left pt-5 pt-md-0">
            	<h1 class="mb-3" style="color:yellow;">Hora de Buscar nuevos zapatos?</h1>
            	<div class="intro-text text-center text-md-left">
              	<h3 class="mb-5" style="color:ivory">Disfruta y Construye tu propio mañana, junto a Heist, la distribuidora mas popular de calzado del mercado online.</h3>
              	<p>
                	<a href="#" class="btn btn-sm btn-primary">Vamos a Comprar Ya!</a>
			  	</p>
            </div>
          </div>
        </div>
      </div>
	</div>


    <div class="site-section block-2 site-blocks-2">
      <div class="container">
        <div class="row">
          <div class="col-sm-6 col-md-6 col-lg-4 mb-4 mb-lg-0" data-aos="fade" data-aos-delay="">
            <a class="block-2-item" href="<?= base_url(); ?>index.php/Catalogo">
              <figure class="image">
                <img src="http://www.maddmovies.co.uk/images/women%20clothing/tops/Simple%20Style%20Agaci%20White%20Black%20Ptrn-%20Tops%20Stripe%20Flounce%20Stripes%20Casual%20Round%20Long%20round%20neckline%20Longline%20hem%2072UM061.jpg" alt="" class="img-fluid">
              </figure>
              <div class="text">
                <span class="text-uppercase">Coleccion</span>
                <h3>Mujeres</h3>
              </div>
            </a>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="100">
            <a class="block-2-item" href="<?= base_url(); ?>index.php/Catalogo">
              <figure class="image">
                <img src="https://i.pinimg.com/736x/3c/d4/68/3cd468717ee35e34f8a4f95dc0c261b1--cute-little-girls-little-girl-dresses.jpg" alt="" class="img-fluid">
              </figure>
              <div class="text">
                <span class="text-uppercase">Coleccion</span>
                <h3>Niños</h3>
              </div>
            </a>
          </div>
          <div class="col-sm-6 col-md-6 col-lg-4 mb-5 mb-lg-0" data-aos="fade" data-aos-delay="200">
            <a class="block-2-item" href="<?= base_url(); ?>index.php/Catalogo">
              <figure class="image">
                <img src="https://i.pinimg.com/originals/95/55/9c/95559ca9a79f7da23522cb702e5eb2e8.jpg" alt="" class="img-fluid">
              </figure>
              <div class="text">
                <span class="text-uppercase">Coleccion</span>
                <h3>Hombres</h3>
              </div>
            </a>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section block-3 site-blocks-2 bg-light">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 site-section-heading text-center pt-4">
            <h2>Nuestros Productos!</h2>
          </div>
        </div>
		<br>

    <div class="row no-gutters products">
    <?php foreach ($listaProductos->result() as $row) { ?>
      <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
                  <div class="block-4 text-center border">
                      <figure class="block-4-image">
                        <a href="<?= base_url() ?>index.php/detalles/producto/<?php print $row->ID ?>" class="item">
                        <img src="<?php echo $row->Imagen ?>" style ="height:300px;"alt="Image placeholder" class="img-fluid"></a>
                      </figure> 
						<div class="block-4-text p-4">
                         <h3><a class="text-primary font-weight-bold"><?php echo $row->Nombre ?></a></h3>
                            <p class="mb-0">Descripcion</p>
              <p class="text-primary font-weight-bold">$<?php echo number_format($row->Precio) ?>.000 CLP</p>

							<form action="" method="post">

							<input type="hidden" name="id" id="id" value="<?php echo $this->encryption->encrypt($row->ID); ?>">
							<input type="hidden" name="nombre" id="nombre" value="<?php echo $this->encryption->encrypt($row->Nombre);?>">
							<input type="hidden" name="precio" id="precio" value="<?php echo $this->encryption->encrypt($row->Precio);?>">
							<input type="hidden" name="cantidad" id="cantidad" value="<?php echo $this->encryption->encrypt(1);?>">

							</form>
						</div>
					</div>
        </div>
<?php } ?>
</div>

		</div>
