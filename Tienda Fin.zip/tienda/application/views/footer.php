</div>
<footer class="site-footer border-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <div class="row">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Navegacion</h3><!--Arreglar navegacion-->
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="<?= base_url();?>index.php/Home">Inicio</a></li>
                  <li><a href="<?= base_url(); ?>index.php/Catalogo">Catalogo</a></li>
                  <li><a href="<?= base_url() ?>index.php/Carro">Revisar Carrito</a></li>
                  <li><a href="#">Posees alguna cuenta? Click Aqui!</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">
            <h3 class="footer-heading mb-4">Aprovecha las mejores Promociones!</h3>
            <a href="<?= base_url(); ?>index.php/Catalogo" class="block-6"><?php //Considerar el agregar un link hacia productos?>
              <img src="https://http2.mlstatic.com/shoes-tenis-zapatillas-nuevo-modelo-estilo-unisex-D_NQ_NP_955926-MCO29719391021_032019-Q.jpg" alt="Image placeholder" class="img-fluid rounded mb-4">
              <h3 class="font-weight-light  mb-0">Encuentra el Calzado que mas te acomode</h3>
              <p>Promociones validas hasta agotar stock. &mdash; Invierno, 2019</p>
            </a>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Contactanos!</h3>
              <ul class="list-unstyled">
                <li class="address">Universidad De Valparaiso, Facultad de Ingenieria</li>
                <li class="phone">+9 12345678</li>
                <li class="email">HeistCalzados@Heist.cl</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <p>
            <div class="col-12 text-center"> Heist © 2019 - Derechos Reservados </div>
            </p>
          </div>
          
        </div>
      </div>
    </footer>
  </div>

  <script src="<?= base_url() ?>/plantilla/js/jquery-3.3.1.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/jquery-ui.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/popper.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/bootstrap.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/owl.carousel.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/jquery.magnific-popup.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/aos.js"></script>

  <script src="<?= base_url() ?>/plantilla/js/main.js"></script>
    
  </body>
</html>